package com.example.pbookmark.domain;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/*
Bookmark entity and BookmarkRepository are not public. They are package-private scoped classes/interfaces.
They are supposed to be used by BookmarkService only and is hidden from outside the
com.example.pbookmark.domain package.
 */
@Repository
interface BookmarkRepository extends JpaRepository<Bookmark,Long> {
    @Query("""
               SELECT
                new com.example.pbookmark.domain.BookmarkDTO(b.id, b.title, b.url, b.createdAt,b.updatedAt)
               FROM Bookmark b
            """)
    Page<BookmarkDTO> findBookmarks(Pageable pageable);

    /**
     * This is a constructor expression in JPQL.
     * Instead of returning full Bookmark entities, it directly creates BookmarkDTO objects.
     * The BookmarkDTO class must have a matching constructor
     * LOWER(b.title) LIKE LOWER(CONCAT('%', :search, '%'))
     * - LOWER(...) converts both the database field and the search term to lowercase → makes the search case-insensitive.
     * - CONCAT('%', :search, '%') creates a pattern that matches any string containing the search term.
     * - CONCAT('%', :search, '%') wraps the search term with % wildcards → matches anywhere in the string.
     * GENERATED SQL :
     * SELECT b.id, b.title, b.url, b.created_at
     * FROM bookmarks b
     * WHERE LOWER(b.title) LIKE LOWER('%java%')
     *    OR LOWER(b.url) LIKE LOWER('%java%')
     * ORDER BY b.created_at DESC
     * LIMIT 10 OFFSET 0;
     *
     * When you use a custom JPQL query like this, Spring Data JPA does not automatically apply the Sort from the Pageable unless you explicitly add ORDER BY in the query.
     *
     * That’s why sorting works for createdAt (because you hardcoded it earlier), but not for id or title.
     * @param search
     * @param pageable
     * @return
     */
    @Query("""
           SELECT new com.example.pbookmark.domain.BookmarkDTO(b.id, b.title, b.url, b.createdAt,b.updatedAt)
           FROM Bookmark b
           WHERE LOWER(b.title) LIKE LOWER(CONCAT('%', :search, '%'))
              OR LOWER(b.url) LIKE LOWER(CONCAT('%', :search, '%'))
           """)
    Page<BookmarkDTO> searchBookmarks(@Param("search") String search, Pageable pageable);

    @Query("""
           SELECT
            new com.example.pbookmark.domain.BookmarkDTO(b.id, b.title, b.url, b.createdAt,b.updatedAt)
           FROM Bookmark b
           WHERE b.id = :Id
        """)
    Optional<BookmarkDTO> findBookmarkById(@Param("Id") Long id);

    Boolean existsByTitle(String title);
}
