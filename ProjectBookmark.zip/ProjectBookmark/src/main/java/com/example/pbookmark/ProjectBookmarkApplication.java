package com.example.pbookmark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
@EnableCaching
public class ProjectBookmarkApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjectBookmarkApplication.class, args);
    }

}
