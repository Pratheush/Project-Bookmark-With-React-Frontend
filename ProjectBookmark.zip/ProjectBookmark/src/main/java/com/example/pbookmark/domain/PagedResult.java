package com.example.pbookmark.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

/**
 * 🔎 Why It’s Different in Records
 * A record is implicitly final and has a canonical constructor + auto‑generated equals, hashCode, and toString.
 * If you make a record implements Serializable, you can still add a serialVersionUID,
 * but it must be declared as a static field inside the record body (not in the header).
 *
 * ✅ Key Points
 * serialVersionUID must be declared inside the record body, not in the record header.
 * It works exactly the same way as in a normal class: ensures serialization compatibility.
 * You don’t need getters/setters — records already provide accessors.
 * This is considered best practice if your record is Serializable and may be cached, sent across JVMs, or stored in sessions.
 *
 *  serialVersionUID → ensures serialization compatibility across JVMs and caches.
 * @Builder → Lombok generates a builder, making construction readable and safe:
 * PagedResult<String> result = PagedResult.<String>builder()
 *     .data(List.of("A", "B"))
 *     .totalElements(2)
 *     .pageNumber(0)
 *     .totalPages(1)
 *     .isFirst(true)
 *     .isLast(true)
 *     .hasNext(false)
 *     .hasPrevious(false)
 *     .build();
 *
 * Convenience factory method (of) → encapsulates pagination logic (first/last/next/previous flags)
 * so controllers/services don’t repeat it.
 *
 * Using @Builder avoids long positional constructors and makes code self‑documenting.
 * The of method ensures consistent pagination flag calculation across your app.
 * 👉 This version is production‑ready: it’s concise, immutable, serializable, and easy to construct in controllers/services.
 */
@Builder
public record PagedResult<T>(

        List<T> data,
        long totalElements,
        int pageNumber,
        int totalPages,
        @JsonProperty("isFirst") boolean isFirst,
        @JsonProperty("isLast") boolean isLast,
        @JsonProperty("hasNext") boolean hasNext,

        //defining a logical property for a field that will be used for both serializing and deserializing
        @JsonProperty("hasPrevious") boolean hasPrevious) implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    // ✅ Optional convenience factory method
    public static <T> PagedResult<T> of(
            List<T> data,
            long totalElements,
            int pageNumber,
            int totalPages
    ) {
        return PagedResult.<T>builder()
                .data(data)
                .totalElements(totalElements)
                .pageNumber(pageNumber)
                .totalPages(totalPages)
                .isFirst(pageNumber == 0)
                .isLast(pageNumber == totalPages - 1)
                .hasNext(pageNumber < totalPages - 1)
                .hasPrevious(pageNumber > 0)
                .build();
    }
}
