package com.example.pbookmark.domain;

import jakarta.persistence.*;
import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.Instant;

/**
 * Note that the entity class is not public,
 * so it’s visibility is limited to com.example.pbookmark.domain package.
 * ✅ Best Practice in Companies
 * Composite key classes → Always implements Serializable.
 * Entities → Optional, but many teams add it by convention for consistency.
 * Example:
 * @Entity
 * @Table(name = "customer")
 * public class Customer implements Serializable {
 *     private static final long serialVersionUID = 1L;
 *     ...
 * }
 * DTOs → Often implement Serializable if they’re passed between layers or stored in sessions.
 *
 * 🚀 Recommendation for Your Project
 * Since you’re building a scalable backend:
 * Keep Serializable on ID classes (SalesId, OrderRowId, CurrencyExchangeId).
 * For entities like Customer, Order, Store, Product:
 * Add implements Serializable if you plan to use distributed caching or session replication.
 * Otherwise, it’s optional — Hibernate can persist them without it.
 *
 * not every entity needs Serializable, but every composite key class does.
 * Many companies add it to all entities for consistency, especially in large projects with caching or clustering.
 *
 *  private static final long serialVersionUID = 1L;
 * 🔎 What serialVersionUID Does
 * It’s a unique identifier for a serialized class.
 * When Java serializes an object, it writes this ID into the byte stream.
 * When deserializing, Java checks if the class’s serialVersionUID matches the one in the stream.
 * ✅ If it matches → deserialization succeeds.
 * ❌ If it doesn’t → InvalidClassException is thrown.
 *
 * ✅ Why Companies Add It
 * Consistency: Prevents Java from auto‑generating a random serialVersionUID (which can change between compilers).
 * Stability: Ensures backward compatibility when entities are cached, stored in sessions, or sent across JVMs.
 * Best practice: Most teams add it to every Serializable class, even if not strictly required.
 *
 * 🚀 Practical Rule
 * Always add serialVersionUID when you implement Serializable.
 * Use 1L for the first version.
 * Increment/change it only if you make incompatible changes to the class structure.
 * serialVersionUID = 1L is a manually defined version number. If you later change the class (add/remove fields),
 * you can update this number to indicate incompatibility with older serialized forms.
 */
@Entity
@Table(name = "bookmarks")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(value = {AuditingEntityListener.class, AuditBookmark.class})
class Bookmark implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String title;
    @Column(nullable = false)
    private String url;

    @CreatedDate
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    //@LastModifiedDate
    //@Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updated_at", insertable = false, updatable = true, nullable = true)
    private Instant updatedAt;

    /*@PreUpdate
    public void updateTimestamps(){
        this.updatedAt=Instant.now();
    }*/

    /*@PrePersist
    public void createTimestamps(){
        this.createdAt= Instant.now();
    }*/
}
