package com.example.pbookmark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.TestConfiguration;

import org.springframework.context.annotation.Bean;
/*import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;*/


@TestConfiguration(proxyBeanMethods = false)
public class TestApplication {

    /*@Bean
    @ServiceConnection
    PostgreSQLContainer<?> postgresContainer() {
        return new PostgreSQLContainer<>(DockerImageName.parse("postgres:15.4-alpine"));
    }

    public static void main(String[] args) {
        SpringApplication
                .from(BookMarkApplication::main)
                .with(TestApplication.class)
                .run(args);
    }*/
}
