package com.example.pbookmark;

import org.springframework.boot.SpringApplication;

public class TestProjectBookmarkApplication {

    public static void main(String[] args) {
        SpringApplication.from(ProjectBookmarkApplication::main).with(TestcontainersConfiguration.class).run(args);
    }

}
